This ZIP file contains an update for GRASP Reporting.
Generally these are small fixes for the last release.

Extract all files inside the GRASPReporting folder.
Ensure that existing files are overwritten.