This ZIP file contains an update for GRASP Reporting.
Generally these are small fixes for the last release.

Extract all files into the GRASPReporting folder so that subdirectories are respected. Ensure that existing files are overwritten.